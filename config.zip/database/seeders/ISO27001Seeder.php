<?php

namespace Database\Seeders;

use App\Models\Document;
use App\Models\DocumentTypes;
use App\Models\Family;
use App\Models\Framework;
use Illuminate\Database\Seeder;
use App\Models\FrameworkControl;
use App\Models\FrameworkControlMapping;
use App\Models\FrameworkControlTest;
use App\Models\Regulator;
use Illuminate\Support\Facades\DB;

class ISO27001Seeder extends Seeder
{
    protected $options;
    protected $regulatorId;
    
    public function __construct()
    {
        // Get the environment variable
        $options = getenv('SEEDER_OPTIONS');
        $regulatorId = getenv('SEEDER_REGULATION');
         
        // Debugging: Check the raw environment variable
        // var_dump($options);

        if($regulatorId){
             // Split the string into an array using comma as the delimiter
             $this->regulatorId = json_decode($regulatorId, true) ?: [];
        }else{
            $this->regulatorId = [];

        }
        // Check if options are present
        if ($options) {
            // Split the string into an array using comma as the delimiter
            $this->options = json_decode($options, true) ?: [];
        } else {
            // Set options as an empty array if no options are present
            $this->options = [];
        }
    }

    public function run()
    {
        DB::transaction(function () {
            $currentDateTime = now();
            $currentDate = date('Y-m-d');
            $nextReviewDate = date('Y-m-d', strtotime('+180 days', strtotime($currentDate)));
            $regulation = getenv('SEEDER_REGULATION');

            // Debugging: Check the condition before entering the if block

            if (in_array('install_document', $this->options)) {

                // DocumentTypes::updateOrCreate(
                //     ['name' => 'نماذج سياسات الأمن السيبراني'], // Attributes to search for
                //     ['icon' => 'fas fa-lock'] // Attributes to update or create
                // );

                // DocumentTypes::updateOrCreate(
                //     ['name' => 'معايير الأمن السيبراني'],
                //     ['icon' => 'fas fa-lock']
                // );

                // DocumentTypes::updateOrCreate(
                //     ['name' => 'الاجراءات'],
                //     ['icon' => 'fas fa-bug']
                // );

                // DocumentTypes::updateOrCreate(
                //     ['name' => 'صمود الأمن السيبراني'],
                //     ['icon' => 'fas fa-unlink']
                // );
            }



            // Insert framework data
            $framework = Framework::create([
                'name' => 'ISO-27001',
                'description' => "ISO/IEC 27001 is is the world’s best-known standard for information security management systems (ISMS) and their requirements. Additional best practice in data protection and cyber resilience are covered by more than a dozen standards in the ISO/IEC 27000 family. Together, they enable organizations of all sectors and sizes to manage the security of assets such as financial information, intellectual property, employee data and information entrusted by third parties.",
                'icon' => 'fa-user-circle',
                'status' => '1',
                'regulator_id'=>$this->regulatorId,

            ]);


            // Main domains with their subdomains
            $mainDomains = [
                [

                    'name' => 'Annex A.5 – Information Security Policies',
                    'order' => '10',
                    'subdomains' => [
                        [
                            'name' => 'Management direction for information Security',
                            'order' => '1',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.6 – Organisation of Information Security',
                    'order' => '11',
                    'subdomains' => [
                        [
                            'name' => 'Internal organization',
                            'order' => '1',
                        ],
                        [
                            'name' => 'Mobile devices and teleworking',
                            'order' => '2',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.7 – Human Resource Security',
                    'order' => '12',
                    'subdomains' => [
                        [
                            'name' => 'Prior to employment',
                            'order' => '1',
                        ],
                        [
                            'name' => 'During employment',
                            'order' => '2',
                        ],
                        [
                            'name' => 'Termination and change of employment',
                            'order' => '3',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.8 – Asset Management',
                    'order' => '13',
                    'subdomains' => [
                        [
                            'name' => 'Responsibility for assets',
                            'order' => '1',
                        ],
                        [
                            'name' => 'Information classification',
                            'order' => '2',
                        ],
                        [
                            'name' => 'Media Handling',
                            'order' => '3',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.9 – Access Control',
                    'order' => '14',
                    'subdomains' => [
                        [
                            'name' => 'Business requirements of access Control',
                            'order' => '1',
                        ],
                        [
                            'name' => 'User access Management',
                            'order' => '2',
                        ],
                        [
                            'name' => 'User responsibilities',
                            'order' => '3',
                        ],
                        [
                            'name' => 'System and application access Control',
                            'order' => '4',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.10 – Cryptography',
                    'order' => '15',
                    'subdomains' => [
                        [
                            'name' => 'Cryptographic Controls',
                            'order' => '1',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.11 – Physical & Environmental Security',
                    'order' => '16',
                    'subdomains' => [
                        [
                            // 'name' => 'Secure areas',
                            'name' => 'Ensuring Secure Physical and Environmental Areas',
                            'order' => '1',
                        ],
                        [
                            'name' => 'Equipment',
                            'order' => '2',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.12 – Operations Security',
                    'order' => '17',
                    'subdomains' => [
                        [
                            'name' => 'Operational Procedures and Responsibilities',
                            'order' => '1',
                        ],
                        [
                            'name' => 'Protection From Malware',
                            'order' => '2',
                        ],
                        [
                            'name' => 'Backup',
                            'order' => '3',
                        ],
                        [
                            'name' => 'Logging and Monitoring',
                            'order' => '4',
                        ],
                        [
                            'name' => 'Control of Operational Software',
                            'order' => '5',
                        ],
                        [
                            'name' => 'Technical Vulnerability Management',
                            'order' => '6',
                        ],
                        [
                            'name' => 'Information Systems and Audit Considerations',
                            'order' => '7',
                        ],
                    ]
                ],
                [
                    'name' => 'Annex A.13 – Communications Security',
                    'order' => '18',
                    'subdomains' => [
                        [
                            'name' => 'Network Security Management',
                            'order' => '1',
                        ],
                        [
                            'name' => 'Information Transfer',
                            'order' => '2',
                        ]
                    ]
                ],

                [
                    'name' => 'Annex A.14 – System Acquisition, Development & Maintenance',
                    'order' => '19',
                    'subdomains' => [
                        [
                            'name' => 'Security Requirements of Information Systems',
                            'order' => '1',
                        ],
                        [
                            'name' => 'Security in Development and Support Processes',
                            'order' => '2',
                        ],
                        [
                            'name' => 'Test data',
                            'order' => '3',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.15 – Supplier Relationships',
                    'order' => '20',
                    'subdomains' => [
                        [
                            'name' => 'Information Security in Supplier Relationships',
                            'order' => '1',
                        ],
                        [
                            'name' => 'Supplier Service Delivery Management',
                            'order' => '2',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.16 – Information Security Incident Management',
                    'order' => '21',
                    'subdomains' => [
                        [
                            // 'name' => 'Management of Information Security incidents and improvements',
                            'name' => 'Management of Information Security incidents, events and Weaknesses',
                            'order' => '1',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.17 – Information Security Aspects of Business Continuity Management',
                    'order' => '22',
                    'subdomains' => [
                        [
                            'name' => 'Information Security Continuity',
                            'order' => '1',
                        ],
                        [
                            'name' => 'Redundancies',
                            'order' => '2',
                        ]
                    ]
                ],
                [
                    'name' => 'Annex A.18 – Compliance',
                    'order' => '23',
                    'subdomains' => [
                        [
                            'name' => 'Compliance with legal and Contractual Requirements',
                            'order' => '1',
                        ],
                        [
                            'name' => 'Information Security Reviews',
                            'order' => '2',
                        ]
                    ]
                ],



            ];

            $subDomainFamilies = [];

            foreach ($mainDomains as $mainDomain) {
                // Create or update the main domain
                $domain = Family::updateOrCreate(
                    ['name' => $mainDomain['name'], 'parent_id' => null],
                    ['order' => $mainDomain['order']]
                );
            
                if (isset($mainDomain['subdomains'])) {
                    foreach ($mainDomain['subdomains'] as $subDomain) {
                        // Create or update the subdomain
                        $subDomainFamily = Family::updateOrCreate(
                            ['name' => $subDomain['name'], 'parent_id' => $domain->id],
                            ['order' => $subDomain['order']]
                        );
                        $subDomainFamilies[$subDomainFamily->id] = $subDomainFamily->parent_id;
                    }
                }
            
                // Sync the main domain with the framework
                $framework->families()->syncWithoutDetaching([
                    $domain->id => ['parent_family_id' => $domain->parent_id],
                ]);
            
                // Sync the subdomains with the framework
                foreach ($subDomainFamilies as $subDomainId => $parentId) {
                    $framework->families()->syncWithoutDetaching([
                        $subDomainId => ['parent_family_id' => $parentId],
                    ]);
                }
            }




            $frameworkControls = [

                [
                    "short_name" => "ISO A.5.1.1",
                    "long_name" => "ISO A.5.1.1",
                    "description" => "Policies for information security  :\r\n A set of policies for information security shall be defined, approved by management, published and communicated to employees and relevant external parties.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.5.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Management direction for information Security'), // Dynamically get family ID
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",


                ],
                [

                    "short_name" => "ISO A.5.1.2",
                    "long_name" => "ISO A.5.1.2",
                    "description" => "Review of the policies for information security  => \r\nThe policies for information security shall be reviewed at planned intervals or if significant changes occur to ensure their continuing suitability, adequacy and effectiveness",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.5.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Management direction for information Security'), // Dynamically get family ID
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",


                ],

                [

                    "short_name" => "ISO A.6.1.1",
                    "long_name" => "ISO A.6.1.1",
                    "description" => "Information security roles and responsibilities  => \r\nAll information security responsibilities shall be defined and allocated.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.6.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Internal organization'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],


                [

                    "short_name" => "ISO A.6.1.2",
                    "long_name" => "ISO A.6.1.2",
                    "description" => "Segregation of duties  => \r\nConflicting duties and areas of responsibility shall be segregated to reduce opportunities for unauthorized or unintentional modification or misuse of the organization’s assets",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.6.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Internal organization'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",


                ],

                [

                    "short_name" => "ISO A.6.1.3",
                    "long_name" => "ISO A.6.1.3",
                    "description" => "Contact with authorities  => \r\nAppropriate contacts with relevant authorities shall be maintained",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.6.1.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Internal organization'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.6.1.4",
                    "long_name" => "ISO A.6.1.4",
                    "description" => "Contact with special interest groups  => \r\nAppropriate contacts with special interest groups or other specialist security forums and professional associations shall be maintained",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.6.1.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Internal organization'),
                    "control_owner" => "1",
                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],

                [
                    "short_name" => "ISO A.6.1.5",
                    "long_name" => "ISO A.6.1.5",
                    "description" => "Information security in project management   => \r\nInformation security shall be addressed in project management, regardless of the type of the project",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.6.1.5",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Internal organization'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.6.2.1",
                    "long_name" => "ISO A.6.2.1",
                    "description" => "Mobile device policy  => A policy and supporting security measures shall be adopted to manage the risks introduced by using mobile devices",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.6.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Mobile devices and teleworking'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",


                ],
                [
                    "short_name" => "ISO A.6.2.2",
                    "long_name" => "ISO A.6.2.2",
                    "description" => "Teleworking  => A policy and supporting security measures shall be implemented to protect information accessed, processed or stored at teleworking sites.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.6.2.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Mobile devices and teleworking'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.7.1.1",
                    "long_name" => "ISO A.7.1.1",
                    "description" => "Screening  => \r\nBackground verification checks on all candidates for employment shall be carried out in accordance with relevant laws, regulations and ethics and shall be proportional to the business requirements, the classification of the information to be accessed and the perceived risks.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.7.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Prior to employment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",


                ],

                [
                    "short_name" => "ISO A.7.1.2",
                    "long_name" => "ISO A.7.1.2",
                    "description" => "Terms and conditions of employment  => \r\nThe contractual agreements with employees and contractors shall state their and the organization’s responsibilities for information security.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.7.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Prior to employment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.7.2.1",
                    "long_name" => "ISO A.7.2.1",
                    "description" => "Management responsibilities  => \r\nManagement shall require all employees and contractors to apply information security in accordance with the established policies and procedures of the organization.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.7.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('During employment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.7.2.2",
                    "long_name" => "ISO A.7.2.2",
                    "description" => "Information security awareness, education and training  => \r\nAll employees of the organization and, where relevant, contractors shall receive appropriate awareness education and training and regular updates in organizational policies and procedures, as relevant for their job function.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.7.2.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('During employment'),
                    "control_owner" => "1",
                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",


                ],

                [
                    "short_name" => "ISO A.7.2.3",
                    "long_name" => "ISO A.7.2.3",
                    "description" => "Disciplinary process  => \r\nThere shall be a formal and communicated disciplinary process in place to take action against employees who have committed an information security breach",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.7.2.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('During employment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],

                [
                    "short_name" => "ISO A.7.3.1",
                    "long_name" => "ISO A.7.3.1",
                    "description" => "Termination or change of employment responsibilities  => \r\nInformation security responsibilities and duties that remain valid after termination or change of employment shall be defined, communicated to the employee or contractor and enforced",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.7.3.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Termination and change of employment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.8.1.1",
                    "long_name" => "ISO A.8.1.1",
                    "description" => "Inventory of assets  => \r\nAssets associated with information and information processing facilities shall be identified and an inventory of these assets shall be drawn up and maintained.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.8.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Responsibility for assets'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",


                ],

                [
                    "short_name" => "ISO A.8.1.2",
                    "long_name" => "ISO A.8.1.2",
                    "description" => "Ownership of assets  => \r\nAssets maintained in the inventory shall be owned.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.8.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Responsibility for assets'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],

                [
                    "short_name" => "ISO A.8.1.3",
                    "long_name" => "ISO A.8.1.3",
                    "description" => "Acceptable use of assets  => \r\nRules for the acceptable use of information and of assets associated with information and information processing facilities shall be identified, documented and implemented.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.8.1.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Responsibility for assets'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],


                [
                    "short_name" => "ISO A.8.1.4",
                    "long_name" => "ISO A.8.1.4",
                    "description" => "Return of assets  => \r\nAll employees and external party users shall return all of the organizational assets in their possession upon termination of their employment, contract or agreement.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.8.1.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Responsibility for assets'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],

                [
                    "short_name" => "ISO A.8.2.1",
                    "long_name" => "ISO A.8.2.1",
                    "description" => "Classification of information  => \r\nInformation shall be classified in terms of legal requirements, value, criticality and sensitivity to unauthorized disclosure or modification",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.8.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information classification'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],

                [
                    "short_name" => "ISO A.8.2.2",
                    "long_name" => "ISO A.8.2.2",
                    "description" => "Labeling of information  => \r\nAn appropriate set of procedures for information labeling shall be developed and implemented in accordance with the information classification scheme adopted by the organization",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.8.2.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information classification'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],

                [
                    "short_name" => "ISO A.8.2.3",
                    "long_name" => "ISO A.8.2.3",
                    "description" => "Handling of assets  => \r\nProcedures for handling assets shall be developed and implemented in accordance with the information classification scheme adopted by the organization",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.8.2.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information classification'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",


                ],
                [
                    "short_name" => "ISO A.8.3.1",
                    "long_name" => "ISO A.8.3.1",
                    "description" => "Management of removable media  => \r\nProcedures shall be implemented for the management of removable media in accordance with the classification scheme adopted by the organization",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.8.3.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Media Handling'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.8.3.2",
                    "long_name" => "ISO A.8.3.2",
                    "description" => "Disposal of media  => \r\nMedia shall be disposed of securely when no longer required, using formal procedures.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.8.3.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Media Handling'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],

                [
                    "short_name" => "ISO A.8.3.3",
                    "long_name" => "ISO A.8.3.3",
                    "description" => "Physical media transfer  => \r\nMedia containing information shall be protected against unauthorized access, misuse or corruption during transportation",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.8.3.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Media Handling'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],

                [
                    "short_name" => "ISO A.9.1.1",
                    "long_name" => "ISO A.9.1.1",
                    "description" => "Access control policy   => \r\nAn access control policy shall be established, documented and reviewed based on business and information security requirements",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Business requirements of access Control'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.9.1.2",
                    "long_name" => "ISO A.9.1.2",
                    "description" => "Access to networks and network services  => \r\nUsers shall only be provided with access to the network and network services that they have been specifically authorized to use",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Business requirements of access Control'),
                    "control_owner" => "1",
                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.9.2.1",
                    "long_name" => "ISO A.9.2.1",
                    "description" => "User registration and de-registration  => \r\nA formal user registration and de-registration process shall be implemented to enable assignment of access rights.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('User access Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.9.2.2",
                    "long_name" => "ISO A.9.2.2",
                    "description" => "User access provisioning  => A formal user access provisioning process shall be implemented to assign or revoke access rights for all user types to all systems and services.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.2.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('User access Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",


                ],
                [
                    "short_name" => "ISO A.9.2.3",
                    "long_name" => "ISO A.9.2.3",
                    "description" => "Management of privileged access rights  => \r\nThe allocation and use of privileged access rights shall be restricted and controlled.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.2.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('User access Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],

                [
                    "short_name" => "ISO A.9.2.4",
                    "long_name" => "ISO A.9.2.4",
                    "description" => "Management of secret authentication information of users  => \r\nThe allocation of secret authentication information shall be controlled through a formal management process.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.2.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('User access Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.9.2.5",
                    "long_name" => "ISO A.9.2.5",
                    "description" => "Review of user access rights   => \r\nAsset owners shall review users’ access rights at regular intervals.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.2.5",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('User access Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.9.2.6",
                    "long_name" => "ISO A.9.2.6",
                    "description" => "Removal or adjustment of access rights   => The access rights of all employees and external party users to information and information processing facilities shall be removed upon termination of their employment, contract or agreement, or adjusted upon change",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.2.6",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('User access Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.9.3.1",
                    "long_name" => "ISO A.9.3.1",
                    "description" => "Use of secret authentication information  => \r\nUsers shall be required to follow the organization’s practices in the use of secret authentication information",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.3.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('User responsibilities'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.9.4.1",
                    "long_name" => "ISO A.9.4.1",
                    "description" => "Information access restriction  => \r\nAccess to information and application system functions shall be restricted in accordance with the access control policy",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.4.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('System and application access Control'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.9.4.2",
                    "long_name" => "ISO A.9.4.2",
                    "description" => "Secure log-on procedures  => \r\nWhere required by the access control policy, access to systems and applications shall be controlled by a secure log-on procedure.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.4.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('System and application access Control'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.9.4.3",
                    "long_name" => "ISO A.9.4.3",
                    "description" => "Password management system   => \r\nPassword management systems shall be interactive and shall ensure quality passwords",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.4.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('System and application access Control'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.9.4.4",
                    "long_name" => "ISO A.9.4.4",
                    "description" => "Use of privileged utility programs  => \r\nThe use of utility programs that might be capable of overriding system and application controls shall be restricted and tightly controlled.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.4.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('System and application access Control'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.9.4.5",
                    "long_name" => "ISO A.9.4.5",
                    "description" => "Access control to program source code  => \r\nAccess to program source code shall be restricted.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.9.4.5",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('System and application access Control'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.10.1.1",
                    "long_name" => "ISO A.10.1.1",
                    "description" => "Policy on the use of cryptographic controls :\r\nA policy on the use of cryptographic controls for protection of information shall be developed and implemented.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.10.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Cryptographic Controls'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.10.1.2",
                    "long_name" => "ISO A.10.1.2",
                    "description" => "Key management   => \r\nA policy on the use, protection and lifetime of cryptographic keys shall be developed and implemented through their whole lifecycle.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.10.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Cryptographic Controls'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.1.1",
                    "long_name" => "ISO A.11.1.1",
                    "description" => "Physical security perimeter   => \r\nSecurity perimeters shall be defined and used to protect areas that contain either sensitive or critical information and information processing facilities.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Ensuring Secure Physical and Environmental Areas'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.1.2",
                    "long_name" => "ISO A.11.1.2",
                    "description" => "Physical entry controls  => \r\nSecure areas shall be protected by appropriate entry controls to ensure that only authorized personnel are allowed access.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Ensuring Secure Physical and Environmental Areas'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.1.3",
                    "long_name" => "ISO A.11.1.3",
                    "description" => "Securing offices, rooms and facilities   => \r\nPhysical security for offices, rooms and facilities shall be designed and applied.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.1.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Ensuring Secure Physical and Environmental Areas'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.1.4",
                    "long_name" => "ISO A.11.1.4",
                    "description" => "Protecting against external and environmental threats  => \r\nPhysical protection against natural disasters, malicious attack or accidents shall be designed and applied.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.1.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Ensuring Secure Physical and Environmental Areas'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.1.5",
                    "long_name" => "ISO A.11.1.5",
                    "description" => "Working in secure areas  => \r\nProcedures for working in secure areas shall be designed and applied.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.1.5",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Ensuring Secure Physical and Environmental Areas'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.1.6",
                    "long_name" => "ISO A.11.1.6",
                    "description" => "Delivery and loading areas  => \r\nAccess points such as delivery and loading areas and other points where unauthorized persons could enter the premises shall be controlled and, if possible, isolated from information processing facilities to avoid unauthorized access.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.1.6",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Ensuring Secure Physical and Environmental Areas'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.2.1",
                    "long_name" => "ISO A.11.2.1",
                    "description" => "Equipment siting and protection  => \r\nEquipment shall be sited and protected to reduce the risks from environmental threats and hazards, and opportunities for unauthorized access.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Equipment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.2.2",
                    "long_name" => "ISO A.11.2.2",
                    "description" => "Supporting utilities  => \r\nEquipment shall be protected from power failures and other disruptions caused by failures in supporting utilities.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.2.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Equipment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.2.3",
                    "long_name" => "ISO A.11.2.3",
                    "description" => "Cabling security  => \r\nPower and telecommunications cabling carrying data or supporting information services shall be protected from interception, interference or damage.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.2.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Equipment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.11.2.4",
                    "long_name" => "ISO A.11.2.4",
                    "description" => "Equipment maintenance  => \r\nEquipment shall be correctly maintained to ensure its continued availability and integrity.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.2.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Equipment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.2.5",
                    "long_name" => "ISO A.11.2.5",
                    "description" => "Removal of assets  => \r\nEquipment, information or software shall not be taken off-site without prior authorization.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.2.5",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Equipment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.2.6",
                    "long_name" => "ISO A.11.2.6",
                    "description" => "Security of equipment and assets off-premises   => \r\nSecurity shall be applied to off-site assets taking into account the different risks of working outside the organization’s premises.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.2.6",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Equipment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.2.7",
                    "long_name" => "ISO A.11.2.7",
                    "description" => "Secure disposal or reuse of equipment   => \r\nAll items of equipment containing storage media shall be verified to ensure that any sensitive data and licensed software has been removed or securely overwritten prior to disposal or re-use.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.2.7",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Equipment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.2.8",
                    "long_name" => "ISO A.11.2.8",
                    "description" => "Unattended user equipment  => \r\nUsers shall ensure that unattended equipment has appropriate protection.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.2.8",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Equipment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.11.2.9",
                    "long_name" => "ISO A.11.2.9",
                    "description" => "Clear desk and clear screen policy   => \r\nA clear desk policy for papers and removable storage media and a clear screen policy for information processing facilities shall be adopted.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.11.2.9",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Equipment'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.1.1",
                    "long_name" => "ISO A.12.1.1",
                    "description" => "Documented operating procedures   => \r\nOperating procedures shall be documented and made available to all users who need them.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Operational Procedures and Responsibilities'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.1.2",
                    "long_name" => "ISO A.12.1.2",
                    "description" => "Change management  => \r\nChanges to the organization, business processes, information processing facilities and systems that affect information security shall be controlled.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Operational Procedures and Responsibilities'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.1.3",
                    "long_name" => "ISO A.12.1.3",
                    "description" => "Capacity management   => \r\nThe use of resources shall be monitored, tuned and projections made of future capacity requirements to ensure the required system performance.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.1.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Operational Procedures and Responsibilities'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.1.4",
                    "long_name" => "ISO A.12.1.4",
                    "description" => "Separation of development, testing and operational environments   => \r\nDevelopment, testing, and operational environments shall be separated to reduce the risks of unauthorized access or changes to the operational environment.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.1.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Operational Procedures and Responsibilities'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.2.1",
                    "long_name" => "ISO A.12.2.1",
                    "description" => "Controls against malware   => \r\nDetection, prevention and recovery controls to protect against malware shall be implemented, combined with appropriate user awareness.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Protection From Malware'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.3.1",
                    "long_name" => "ISO A.12.3.1",
                    "description" => "Information backup   => \r\nBackup copies of information, software and system images shall be taken and tested regularly in accordance with an agreed backup policy.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.3.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Backup'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.4.1",
                    "long_name" => "ISO A.12.4.1",
                    "description" => "Event logging   =>  \r\nEvent logs recording user activities, exceptions, faults and information security events shall be produced, kept and regularly reviewed.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.4.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Logging and Monitoring'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.4.2",
                    "long_name" => "ISO A.12.4.2",
                    "description" => "Protection of log information   => \r\nLogging facilities and log information shall be protected against tampering and unauthorized access.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.4.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Logging and Monitoring'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.4.3",
                    "long_name" => "ISO A.12.4.3",
                    "description" => "Administrator and operator logs  => \r\nSystem administrator and system operator activities shall be logged and the logs protected and regularly reviewed.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.4.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Logging and Monitoring'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.4.4",
                    "long_name" => "ISO A.12.4.4",
                    "description" => "Clock synchronization  =>   \r\nThe clocks of all relevant information processing systems within an organization or security domain shall be synchronized to a single reference time source.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.4.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Logging and Monitoring'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.5.1",
                    "long_name" => "ISO A.12.5.1",
                    "description" => "Installation of software on operational systems   => \r\nProcedures shall be implemented to control the installation of software on operational systems.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.5.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Control of Operational Software'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.6.1",
                    "long_name" => "ISO A.12.6.1",
                    "description" => "Management of technical vulnerabilities   =>   \r\nInformation about technical vulnerabilities of information systems being used shall be obtained in a timely fashion, the organization’s exposure to such vulnerabilities evaluated and appropriate measures taken to address the associated risk.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.6.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Technical Vulnerability Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.6.2",
                    "long_name" => "ISO A.12.6.2",
                    "description" => "Restrictions on software installation   => \r\nRules governing the installation of software by users shall be established and implemented.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.6.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Technical Vulnerability Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.12.7.1",
                    "long_name" => "ISO A.12.7.1",
                    "description" => "Information systems audit controls  => \r\nAudit requirements and activities involving verification of operational systems shall be carefully planned and agreed to minimize disruptions to business processes.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.12.7.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Systems and Audit Considerations'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.13.1.1",
                    "long_name" => "ISO A.13.1.1",
                    "description" => "Network controls  => \r\nNetworks shall be managed and controlled to protect information in systems and applications.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.13.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Network Security Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.13.1.2",
                    "long_name" => "ISO A.13.1.2",
                    "description" => "Security of network services  => \r\nSecurity mechanisms, service levels and management requirements of all network services shall be identified and included in network services agreements, whether these services are provided in-house or outsourced.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.13.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Network Security Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.13.1.3",
                    "long_name" => "ISO A.13.1.3",
                    "description" => "Segregation in networks   => \r\nGroups of information services, users and information systems shall be segregated on networks.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.13.1.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Network Security Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.13.2.1",
                    "long_name" => "ISO A.13.2.1",
                    "description" => "Information transfer policies and procedures   => \r\nFormal transfer policies, procedures and controls shall be in place to protect the transfer of information through the use of all types of communication facilities.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.13.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Transfer'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.13.2.2",
                    "long_name" => "ISO A.13.2.2",
                    "description" => "Agreements on information transfer  :\r\nAgreements shall address the secure transfer of business information between the organization and external parties.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.13.2.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Transfer'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.13.2.3",
                    "long_name" => "ISO A.13.2.3",
                    "description" => "Electronic messaging  => \r\nInformation involved in electronic messaging shall be appropriately protected.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.13.2.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Transfer'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.13.2.4",
                    "long_name" => "ISO A.13.2.4",
                    "description" => "Confidentiality or nondisclosure agreements  => \r\nRequirements for confidentiality or non-disclosure agreements reflecting the organization’s needs for the protection of information shall be identified, regularly reviewed and documented.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.13.2.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Transfer'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.14.1.1",
                    "long_name" => "ISO A.14.1.1",
                    "description" => "Information security requirements analysis and specification   => \r\nThe information security related requirements shall be included in the requirements for new information systems or enhancements to existing information systems.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security Requirements of Information Systems'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.14.1.2",
                    "long_name" => "ISO A.14.1.2",
                    "description" => "Securing application services on public networks  => \r\nInformation involved in application services passing over public networks shall be protected from fraudulent activity, contract dispute and unauthorized disclosure and modification.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security Requirements of Information Systems'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.14.1.3",
                    "long_name" => "ISO A.14.1.3",
                    "description" => "Protecting application services transactions  => \r\nInformation involved in application service transactions shall be protected to prevent incomplete transmission, mis-routing, unauthorized message alteration, unauthorized disclosure, unauthorized message duplication or replay",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.1.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security Requirements of Information Systems'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],  [
                    "short_name" => "ISO A.14.2.1",
                    "long_name" => "ISO A.14.2.1",
                    "description" => "Secure development policy  => Rules for the development of software and systems shall be established and applied to developments within the organization.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security in Development and Support Processes'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ],
                [
                    "short_name" => "ISO A.14.2.2",
                    "long_name" => "ISO A.14.2.2",
                    "description" => "System change control procedures  => \r\nChanges to systems within the development lifecycle shall be controlled by the use of formal change control procedures.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.2.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security in Development and Support Processes'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.14.2.3",
                    "long_name" => "ISO A.14.2.3",
                    "description" => "Technical review of applications after operating platform changes   => \r\nWhen operating platforms are changed, business critical applications shall be reviewed and tested to ensure there is no adverse impact on organizational operations or security.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.2.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security in Development and Support Processes'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.14.2.4",
                    "long_name" => "ISO A.14.2.4",
                    "description" => "Restrictions on changes to software packages  => \r\nModifications to software packages shall be discouraged, limited to necessary changes and all changes shall be strictly controlled.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.2.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security in Development and Support Processes'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.14.2.5",
                    "long_name" => "ISO A.14.2.5",
                    "description" => "Secure system engineering principles  => \r\nPrinciples for engineering secure systems shall be established, documented, maintained and applied to any information system implementation efforts.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.2.5",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security in Development and Support Processes'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.14.2.6",
                    "long_name" => "ISO A.14.2.6",
                    "description" => "Secure development environment   => \r\nOrganizations shall establish and appropriately protect secure development environments for system development and integration efforts that cover the entire system development lifecycle.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.2.6",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security in Development and Support Processes'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.14.2.7",
                    "long_name" => "ISO A.14.2.7",
                    "description" => "Outsourced development   =>  \r\nThe organization shall supervise and monitor the activity of outsourced system development.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.2.7",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security in Development and Support Processes'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.14.2.8",
                    "long_name" => "ISO A.14.2.8",
                    "description" => "System security testing  => \r\nAcceptance testing programs and related criteria shall be established for new information systems, upgrades and new versions.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.2.8",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security in Development and Support Processes'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.14.2.9",
                    "long_name" => "ISO A.14.2.9",
                    "description" => "System acceptance testing  => \r\nAcceptance testing programs and related criteria shall be established for new information systems, upgrades and new versions.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.2.9",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Security in Development and Support Processes'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.14.3.1",
                    "long_name" => "ISO A.14.3.1",
                    "description" => "Protection of test data   => \r\nTest data shall be selected carefully, protected and controlled.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.14.3.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Test data'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.15.1.1",
                    "long_name" => "ISO A.15.1.1",
                    "description" => "Information security policy for supplier relationships   => \r\nInformation security requirements for mitigating the risks associated with supplier’s access to the organization’s assets shall be agreed with the supplier and documented.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.15.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Security in Supplier Relationships'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.15.1.2",
                    "long_name" => "ISO A.15.1.2",
                    "description" => "Addressing security within supplier agreements   => \r\nAll relevant information security requirements shall be established and agreed with each supplier that may access, process, store, communicate, or provide IT infrastructure components for, the organization’s information.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.15.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Security in Supplier Relationships'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.15.1.3",
                    "long_name" => "ISO A.15.1.3",
                    "description" => "Information and communication technology supply chain  => \r\nAgreements with suppliers shall include requirements to address the information security risks associated with information and communications technology services and product supply chain.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.15.1.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Security in Supplier Relationships'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.15.2.1",
                    "long_name" => "ISO A.15.2.1",
                    "description" => "Monitoring and review of supplier services  => \r\nOrganizations shall regularly monitor, review and audit supplier service delivery.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.15.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Supplier Service Delivery Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.15.2.2",
                    "long_name" => "ISO A.15.2.2",
                    "description" => "Managing changes to supplier services  => \r\nChanges to the provision of services by suppliers, including maintaining and improving existing information security policies, procedures and controls, shall be managed, taking account of the criticality of business information, systems and processes involved and re-assessment of risks.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.15.2.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Supplier Service Delivery Management'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.16.1.1",
                    "long_name" => "ISO A.16.1.1",
                    "description" => "Responsibilities and procedures  => \r\nManagement responsibilities and procedures shall be established to ensure a quick, effective and orderly response to information security incidents.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.16.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Management of Information Security incidents, even...'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.16.1.2",
                    "long_name" => "ISO A.16.1.2",
                    "description" => "Reporting information security events  => \r\nInformation security events shall be reported through appropriate management channels as quickly as possible.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.16.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Management of Information Security incidents, even...'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.16.1.3",
                    "long_name" => "ISO A.16.1.3",
                    "description" => "Reporting information security weaknesses  => \r\nEmployees and contractors using the organization’s information systems and services shall be required to note and report any observed or suspected information security weaknesses in systems or services.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.16.1.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Management of Information Security incidents, even...'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.16.1.4",
                    "long_name" => "ISO A.16.1.4",
                    "description" => "Assessment of and decision on information security events  => \r\nInformation security events shall be assessed and it shall be decided if they are to be classified as information security incidents.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.16.1.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Management of Information Security incidents, even...'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.16.1.5",
                    "long_name" => "ISO A.16.1.5",
                    "description" => "Response to information security incidents  => \r\nInformation security incidents shall be responded to in accordance with the documented procedures.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.16.1.5",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Management of Information Security incidents, even...'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.16.1.6",
                    "long_name" => "ISO A.16.1.6",
                    "description" => "Learning from information security incidents  => \r\nKnowledge gained from analyzing and resolving information security incidents shall be used to reduce the likelihood or impact of future incidents.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.16.1.6",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Management of Information Security incidents, even...'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.16.1.7",
                    "long_name" => "ISO A.16.1.7",
                    "description" => "Collection of evidence  => \r\nThe organization shall define and apply procedures for the identification, collection, acquisition and preservation of information, which can serve as evidence.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.16.1.7",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Security Continuity'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.17.1.1",
                    "long_name" => "ISO A.17.1.1",
                    "description" => "Planning information security continuity  => \r\nThe organization shall determine its requirements for information security and the continuity of information security management in adverse situations, e.g. during a crisis or disaster.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.17.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Security Continuity'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.17.1.2",
                    "long_name" => "ISO A.17.1.2",
                    "description" => "Implementing information security continuity  => \r\nThe organization shall establish, document, implement and maintain processes, procedures and controls to ensure the required level of continuity for information security during an adverse situation.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.17.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Security Continuity'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.17.1.3",
                    "long_name" => "ISO A.17.1.3",
                    "description" => "Verify, review and evaluate information security continuity  => \r\nThe organization shall verify the established and implemented information security continuity controls at regular intervals in order to ensure that they are valid and effective during adverse situations.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.17.1.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Security Continuity'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.17.2.1",
                    "long_name" => "ISO A.17.2.1",
                    "description" => "Availability of information processing facilities  => \r\nInformation processing facilities shall be implemented with redundancy sufficient to meet availability requirements.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.17.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Redundancies'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.18.1.1",
                    "long_name" => "ISO A.18.1.1",
                    "description" => "Identification of applicable legislation and contractual requirements  =>  \r\nAll relevant legislative statutory, regulatory, contractual requirements and the organization’s approach to meet these requirements shall be explicitly identified, documented and kept up to date for each information system and the organization.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.18.1.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Compliance with legal and Contractual Requirements'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.18.1.2",
                    "long_name" => "ISO A.18.1.2",
                    "description" => "Intellectual property rights :\r\nAppropriate procedures shall be implemented to ensure compliance with legislative, regulatory and contractual requirements related to intellectual property rights and use of proprietary software products.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.18.1.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Compliance with legal and Contractual Requirements'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.18.1.3",
                    "long_name" => "ISO A.18.1.3",
                    "description" => "Protection of records  => \r\nRecords shall be protected from loss, destruction, falsification, unauthorized access and unauthorized release, in accordance with legislative, regulatory, contractual and business requirements.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.18.1.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Compliance with legal and Contractual Requirements'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.18.1.4",
                    "long_name" => "ISO A.18.1.4",
                    "description" => "Privacy and protection of personally identifiable information  => \r\nPrivacy and protection of personally identifiable information shall be ensured as required in relevant legislation and regulation where applicable.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.18.1.4",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Compliance with legal and Contractual Requirements'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.18.1.5",
                    "long_name" => "ISO A.18.1.5",
                    "description" => "Regulation of cryptographic controls   => \r\nCryptographic controls shall be used in compliance with all relevant agreements, legislation and regulations.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.18.1.5",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Compliance with legal and Contractual Requirements'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.18.2.1",
                    "long_name" => "ISO A.18.2.1",
                    "description" => "Independent review of information security  => \r\nThe organization’s approach to managing information security and its implementation (i.e. control objectives, controls, policies, processes and procedures for information security) shall be reviewed independently at planned intervals or when significant changes occur.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.18.2.1",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Security Reviews'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.18.2.2",
                    "long_name" => "ISO A.18.2.2",
                    "description" => "Compliance with security policies and standards  => \r\nManagers shall regularly review the compliance of information processing and procedures within their area of responsibility with the appropriate security policies, standards and any other security requirements.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.18.2.2",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Security Reviews'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ], [
                    "short_name" => "ISO A.18.2.3",
                    "long_name" => "ISO A.18.2.3",
                    "description" => "Technical compliance review  => \r\nInformation systems shall be regularly reviewed for compliance with the organization’s information security policies and standards.",
                    "supplemental_guidance" => null,
                    "control_number" => "ISO A.18.2.3",
                    "control_status" => "Not Implemented",
                    "family" => $this->getFamilyIdByName('Information Security Reviews'),
                    "control_owner" => "1",

                    "submission_date" => $currentDateTime,
                    "status" => "1",
                    "deleted" => "0",

                ]
            ];
            foreach ($frameworkControls as $controlData) {
                $this->createControlAndTests($controlData, null, $framework->id);
            }
        });
    }

    private function createControlAndTests($controlData, $parentId = null, $frameworkId)
    {
        // Remove the 'children' key if it exists
        $dataToInsert = $controlData;
        unset($dataToInsert['children']);

        // Remove the 'document' key to avoid the array to string conversion issue
        $documentData = $dataToInsert['document'] ?? []; // Store document data separately
        unset($dataToInsert['document']);

        // Ensure that 'parent_id' is set correctly
        $dataToInsert['parent_id'] = $parentId;

        // Log the data to be inserted
        \Log::info('Data to insert:', $dataToInsert);

        // Create or update the FrameworkControl record
        $control = FrameworkControl::create($dataToInsert);

        // Handle associated documents
        // if (in_array('install_document', $this->options)) {
        //     if (isset($documentData) && !empty($documentData)) {
        //         foreach ($documentData as $docData) {

        //             $this->createOrUpdateDocument($docData, $control->id);
        //         }
        //     }
        // }
        // Create a FrameworkControlTest record associated with the newly created control
        FrameworkControlTest::create([
            "tester" => "1",
            "last_date" => now(),
            "next_date" => now(),
            "name" => $control->short_name,
            "framework_control_id" => $control->id,
        ]);

        // Create a FrameworkControlMapping record for the newly created control
        FrameworkControlMapping::create([
            "framework_control_id" => $control->id,
            "framework_id" => $frameworkId,
        ]);

        // Recursively handle child controls if they exist
        if (isset($controlData['children'])) {
            foreach ($controlData['children'] as $childControlData) {
                $this->createControlAndTests($childControlData, $control->id, $frameworkId);
            }
        }
    }


    // private function createOrUpdateDocument($documentData, $controlId)
    // {
    //     if (isset($documentData) && !empty($documentData)) {
    //         \Log::info('Processing document data:', $documentData);

    //         $documentName = $documentData['document_name'];
    //         \Log::info('Document Name:', ['document_name' => $documentName]);

    //         $document = Document::where('document_name', $documentName)->first();

    //         if ($document) {
    //             // Ensure control_ids is a string or an array, depending on your schema
    //             $existingControlIds = $document->control_ids ? explode(',', $document->control_ids) : [];
    //             if (!in_array($controlId, $existingControlIds)) {
    //                 $existingControlIds[] = $controlId;
    //             }
    //             \Log::info('Updating document with ID:', ['id' => $document->id, 'control_ids' => $existingControlIds]);
    //             $document->control_ids = implode(',', $existingControlIds); // Convert back to a string if necessary
    //             $document->save();
    //         } else {
    //             \Log::info('Creating new document with name:', ['document_name' => $documentName]);
    //             Document::create([
    //                 'document_type' => $documentData['document_type'],
    //                 'privacy' => $documentData['privacy'],
    //                 'document_name' => $documentName,
    //                 'document_status' => $documentData['document_status'],
    //                 'creation_date' => $documentData['creation_date'],
    //                 'last_review_date' => $documentData['last_review_date'],
    //                 'review_frequency' => $documentData['review_frequency'],
    //                 'next_review_date' => $documentData['next_review_date'],
    //                 'control_ids' => implode(',', [$controlId]), // Ensure this is a string if needed
    //                 'framework_ids' => $documentData['framework_ids'],
    //                 'document_owner' => $documentData['document_owner'],
    //                 'additional_stakeholders' => $documentData['additional_stakeholders'],
    //                 'team_ids' => $documentData['team_ids'],
    //                 'created_by' => $documentData['created_by']
    //             ]);
    //         }
    //     } else {
    //         \Log::info('Document data is empty or not set.');
    //     }
    // }


    private function getFamilyIdByName($familyName)
    {
        return Family::where('name', $familyName)->value('id');
    }

    private function getDocumentIdByName($documentTypeName)
    {
        return DocumentTypes::where('name', $documentTypeName)->value('id');
    }

    public function debugOptions()
    {
        return $this->options;
    }
}
